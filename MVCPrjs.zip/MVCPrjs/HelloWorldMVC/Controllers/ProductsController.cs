﻿using HelloWorldMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldMVC.Controllers
{
    public class ProductsController : Controller
    {
        // GET: Products
        public ActionResult Index()
        {
            var store =(List<Product>)HttpContext.Application["store"];
            return View(store);
        }

        [HttpGet]
        public ActionResult AddItem(int id)
        {
            //get the product details from the store based on Id
            var store = (List<Product>)HttpContext.Application["store"];
            var storeItem = store.Where(p => p.Id == id).SingleOrDefault();            

            //get the session cart and add the item to the cart
            var cart = (Cart)Session["cart"];
            var cartItems = cart.Items;
            var cartItem = cartItems.Where(p => p.Id == id).SingleOrDefault();
            if(cartItem!=null)
            {
                cartItem.Quantity++;
            }
            else
            {
                cartItem = new Product
                {
                    Id=storeItem.Id,
                    Name=storeItem.Name,
                    Price=storeItem.Price,
                    Picture=storeItem.Picture,
                    Quantity=1
                };
                cartItems.Add(cartItem);
            }            

            //update the session cart
            Session["cart"] = cart;

            //update the store quantity
            var product = store.Where(p => p.Id == id).SingleOrDefault();
            product.Quantity--;
            HttpContext.Application["store"] = store;

            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Checkout()
        {
            var cart = (Cart)Session["cart"];
            return View(cart);
        }
    }
}