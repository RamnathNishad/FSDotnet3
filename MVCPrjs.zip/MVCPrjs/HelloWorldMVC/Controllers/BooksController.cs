﻿using HelloWorldMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldMVC.Controllers
{
    public class BooksController : Controller
    {
        // GET: Books
        public ActionResult Index()
        {
            ViewBag.X = 100;
            ViewData.Add("Y", 200);
            TempData.Add("Z", 300);
            TempData.Keep();
            Session.Add("S", 400);
            var bookVM = new BookViewModel();
            BookViewModel.Books = new List<Book>();
            //bookVM.Books.Add(new Book { BookId = 1, BookName = "MVC3 Getting Started", Price = 240.45 });
            //bookVM.Books.Add(new Book { BookId = 2, BookName = "MVC4 Getting Started", Price = 340.45 });
            //bookVM.Books.Add(new Book { BookId = 3, BookName = "MVC5 Getting Started", Price = 440.55 });

            return View(bookVM);
        }

        [HttpPost]
        public ActionResult Index(BookViewModel bookVM)
        {
            var book = new Book { BookId = Book.i, BookName = bookVM.BookName, Price = bookVM.Price }; ;
            BookViewModel.Books.Add(book);
            return View(bookVM);
        }

        [HttpPost]
        public ActionResult SearchById(int SearchById)
        {
            var book = BookViewModel.Books.Where(o => o.BookId == SearchById).SingleOrDefault();
            if(book==null)
            {
                ViewData.Add("msg", "Book id not present");
                book = new Book();
            }
            return View(book);          
            
        }
    }
}