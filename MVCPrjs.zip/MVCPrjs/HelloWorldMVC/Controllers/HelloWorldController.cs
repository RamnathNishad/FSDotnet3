﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldMVC.Controllers
{
    public class HelloWorldController : Controller
    {
        // GET: HelloWorld
        public ActionResult Index()
        {
            //int x = 100, y = 200;

            ViewData.Add("x", 100);
            ViewData.Add("y", 200);

            string message = "Welcome to India";
            ViewData.Add("msg", message);
            return View();
        }
        
        [HttpGet]
        public ActionResult Home()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Home(int n1,int n2)
        {
            int result = n1 + n2;
            ViewData.Add("result", result);
            return View();
        }
    }
}