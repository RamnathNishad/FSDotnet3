﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using HelloWorldMVC.Models; //for Models

namespace HelloWorldMVC.Controllers
{
    [RoutePrefix("HRMS")]
    public class EmployeesController : Controller
    {
        // GET: Employees
        [Route("Index")]
        public ActionResult Index()
        {
            BusinessLayer bll = new BusinessLayer();
            List<Employee> lstEmps = bll.GetEmps();

            return View(lstEmps);
            
        }

        [HttpGet]
        [Route("AddEmp")]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {    
            BusinessLayer bll = new BusinessLayer();
            var record = bll.GetEmpById(emp.Ecode);
            if(record!=null)
            {
                ModelState.AddModelError("Ecode", "Ecode already exists");
            }

            if (ModelState.IsValid)
            {
                //TODO Insert using Business Layer
               
                bll.AddEmployee(emp);

                return RedirectToAction("Index");
            }
            else
            {
                return View(emp);
            }
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            //Display the confirmation view for delete
            //get the details from BusinessLayer to display

            BusinessLayer bll = new BusinessLayer();
            var emp = bll.GetEmpById(id);

            return View("ConfirmDelete", emp);           
        }

        [HttpGet]
        public ActionResult ConfirmDelete(int id)
        {
            //delete the record and goto Index
            BusinessLayer bll = new BusinessLayer();
            bll.DeleteById(id);
            return RedirectToAction("Index");
        }



        [HttpGet]
        public ActionResult Edit(int id)
        {
            //Get the Record from BusinessLayer for the id
            BusinessLayer bll = new BusinessLayer();
            var emp = bll.GetEmpById(id);

            return View(emp);
        }

        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            if (ModelState.IsValid)
            {
                //update using businesslayer
                BusinessLayer bll = new BusinessLayer();
                bll.UpdateEmp(emp);

                return RedirectToAction("Index");
            }
            else
            {
                return View(emp);
            }
        }

        [HttpGet]
        [Route("GetEmpById/{id:int}")]
        public ActionResult Details(int id)
        {
            BusinessLayer bll = new BusinessLayer();
            var emp = bll.GetEmpById(id);

            return View(emp);
        }


        [HttpPost]
        public ActionResult SearchByDid(int did)
        {
            BusinessLayer bll = new BusinessLayer();
            var lstEmps = bll.GetEmps().Where(o => o.Deptid == did);

            return View("Index", lstEmps);
        }

        [ChildActionOnly]
        public PartialViewResult GetEmpItemView(Employee emp)
        {
            string foreColor = "black";
            if(emp.Salary>5000)
            {
                foreColor = "red";
            }
            ViewData.Add("foreColor", foreColor);

            return PartialView("_EmployeeItemView", emp);
        }
    }
}



//weakly-typed view:- no model is binded
//strongly-typed view:- model is binded with the view and it is 
//accessible inside the view using a special keyword "Model"