using HelloWorldMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace HelloWorldMVC
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            var store = new List<Product>()
            {
                new Product{Id=1,Name="Redme Note 4",Price=12500,Quantity=300,Picture="redme.jpg"},
                new Product{Id=2,Name="iPhone 6",Price=40500,Quantity=200,Picture="iphone.jpg"},
                new Product{Id=3,Name="Samsung Galaxy",Price=13500,Quantity=100,Picture="samsung.jpg"},
                new Product{Id=4,Name="POCO 11",Price=12000,Quantity=150,Picture="poco11.jpg"},
                new Product{Id=5,Name="Realme Prime",Price=15500,Quantity=300,Picture="realme.jpg"}
            };
            Application.Add("store",store );
        }
        protected void Session_Start()
        {
            var cart = new Cart();
            Session.Add("cart", cart);
        }
    }
}
