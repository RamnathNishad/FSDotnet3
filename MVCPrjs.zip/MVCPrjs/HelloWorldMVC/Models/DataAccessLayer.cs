﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace HelloWorldMVC.Models
{
    public class DataAccessLayer
    {
        SqlConnection con;        

        public DataAccessLayer()
        {
            con = new SqlConnection();
            con.ConnectionString = @"Data Source=(localdb)\ProjectsV13;Integrated Security=True;Initial Catalog=DemoDB";
        }
        public List<Employee> GetAllEmps()
        {
            List<Employee> lstEmps = new List<Employee>();

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from tbl_employee";
            cmd.Connection = con;

            con.Open();
            SqlDataReader sdr =cmd.ExecuteReader();

            while(sdr.Read())
            {
                lstEmps.Add(new Employee
                {
                    Ecode=(int)sdr[0],
                    Ename=sdr[1].ToString(),
                    Salary=(int)sdr[2],
                    Deptid=(int)sdr[3]
                });
            }

            sdr.Close();
            con.Close();

            return lstEmps;
        }
        public void AddEmployee(Employee emp)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "insert into tbl_employee values(@ec,@en,@sal,@did)";

            cmd.Parameters.AddWithValue("@ec", emp.Ecode);
            cmd.Parameters.AddWithValue("@en", emp.Ename);
            cmd.Parameters.AddWithValue("@sal", emp.Salary);
            cmd.Parameters.AddWithValue("@did", emp.Deptid);

            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void DeleteEmpById(int id)
        {
            //TODO DELETE By ID using ADO.NET
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "delete from tbl_employee where ecode=" + id;
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void UpdateEmp(Employee emp)
        {
            //TODO UPDATE using ADO.NET
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "update tbl_employee set ename=@en,salary=@sal,deptid=@did where ecode=@ec";

            cmd.Parameters.AddWithValue("@ec", emp.Ecode);
            cmd.Parameters.AddWithValue("@en", emp.Ename);
            cmd.Parameters.AddWithValue("@sal", emp.Salary);
            cmd.Parameters.AddWithValue("@did", emp.Deptid);

            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }
        public Employee GetEmpById(int id)
        {
            Employee emp = null;
            //TODO GET Emp By Id using ADO.NET
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "select * from tbl_employee where ecode="+id;
            cmd.Connection = con;
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();

            if(sdr.Read())
            {
                emp = new Employee
                {
                    Ecode = (int)sdr[0],
                    Ename = sdr[1].ToString(),
                    Salary = (int)sdr[2],
                    Deptid = (int)sdr[3]
                };
            }
            sdr.Close();
            con.Close();

            return emp;
        }
    }
}