﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldMVC.Models
{
    public class Book
    {
        public static int i = 0;
        public  int BookId { get; set; }
        public string BookName { get; set; }
        public double Price { get; set; }
        public Book()
        {
            i++;
        }
    }
}