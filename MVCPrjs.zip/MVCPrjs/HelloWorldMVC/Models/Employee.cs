﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; //for DataAnnotation classes
using System.Linq;
using System.Web;

namespace HelloWorldMVC.Models
{
    public class Employee
    {
        [Required]
        public int Ecode { get; set; }

        [Required]
        [RegularExpression("[A-Z][aA-zZ]*",ErrorMessage ="invalid name, it must be only alphabet with first Capital case")]
        [StringLength(10,MinimumLength =5,ErrorMessage ="Name must be between 5 and 10 characters")]
        public string Ename { get; set; }

        [Required]        
        [Range(1000,30000,ErrorMessage ="Salary must be between 1000/- and 30000/-")]
        public int Salary { get; set; }

        [Required]
        [CustomDeptid(ErrorMessage ="invalid deptid")]
        public int Deptid { get; set; }
    }


    class CustomDeptid : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            int did = Convert.ToInt32(value);

            if(did>=201 && did<=205)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}