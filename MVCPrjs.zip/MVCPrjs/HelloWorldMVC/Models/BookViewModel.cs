﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldMVC.Models
{
    public class BookViewModel
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public double  Price { get; set; }
        public int SearchById { get; set; }
        public static List<Book> Books { get; set; }
        
    }
}