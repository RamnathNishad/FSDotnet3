﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldMVC.Models
{
    public class BusinessLayer
    {
        public List<Employee> GetEmps()
        {
            DataAccessLayer dal = new DataAccessLayer();
            return dal.GetAllEmps();
        }

        public void AddEmployee(Employee emp)
        {
            //TODO INSERT using DataAccessLayer
            DataAccessLayer dal = new DataAccessLayer();
            dal.AddEmployee(emp);
        }
        public void DeleteById(int id)
        {
            //TODO DELETE using DataAccessLayer
            DataAccessLayer dal = new DataAccessLayer();
            dal.DeleteEmpById(id);
        }
        public void UpdateEmp(Employee emp)
        {
            //TODO UPDATE using DataAccessLayer
            DataAccessLayer dal = new DataAccessLayer();
            dal.UpdateEmp(emp);
        }
        public Employee GetEmpById(int id)
        {
            //TODO GetById using DataAccessLayer
            DataAccessLayer dal = new DataAccessLayer();
            return dal.GetEmpById(id);
        }
    }
}