﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HelloWorldMVC.Models
{
    public class Hobby
    {
        public string HobbyName { get; set; }
        public bool IsChecked { get; set; }
    }
}