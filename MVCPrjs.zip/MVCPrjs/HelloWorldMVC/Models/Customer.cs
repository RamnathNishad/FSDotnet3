﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HelloWorldMVC.Models
{
    public class CustomerVM   //ViewModel
    {
        public int Ecode { get; set; }
        public List<string> Gender { get; set; } 
        public string SelectedGender { get; set; }

        public List<string> PaymentModes { get; set; }
        public string SelectedPaymentMode { get; set; }
       
        public List<SelectListItem> Cities { get; set; }
        public string SelectedCity { get; set; }

        public List<string> Hobbies { get; set; }
        public List<string> SelectedHobbies { get; set; }

        public CustomerVM()
        {
            Gender = new List<string> { "Male", "Female" };
            PaymentModes = new List<string> { "Cash", "Card", "UPI" };
            Cities = new List<SelectListItem>
            {
                new SelectListItem{Text="Bangalore",Value="BLR"},
                new SelectListItem{Text="Mysore",Value="MYS"},
                new SelectListItem{Text="Delhi",Value="DLI"}
            };

            Hobbies = new List<string> {"Dancing","Singing","Painting" };
        }
    }
}